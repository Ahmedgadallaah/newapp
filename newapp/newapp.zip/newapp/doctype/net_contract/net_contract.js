frappe.ui.form.on('NetContract', {
    refresh: function(frm) {
        // Custom logic on form refresh
    },
    validate: function(frm) {
        // Custom logic on form validation
    }
});
